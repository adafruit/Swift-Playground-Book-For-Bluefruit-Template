//  Created by Trevor Beaton on 12/14/17.
//  Copyright © 2017 Vanguard Logic LLC. All rights reserved.

import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth


let rcViewController: RCViewController = RCViewController(1)
PlaygroundPage.current.liveView = rcViewController
